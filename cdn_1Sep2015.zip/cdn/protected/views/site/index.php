<?php
/* @var $this SiteController */

$this -> pageTitle = Yii::app() -> name;
?>

<h1>Welcome to <i><?php echo CHtml::encode(Yii::app() -> name); ?></i></h1>

<p>
	<ol>
		<li><a href="<?=$this -> createUrl('/demo') ?>"> Demo Registration</a></li>
		<li><a href="<?=$this -> createUrl('/sample/one') ?>">Sample Registration (Ver 1)</a></li>
		<li><a href="<?=$this -> createUrl('/sample') ?>">Sample Registration (Ver 2)</a></li>
	</ol>
</p>