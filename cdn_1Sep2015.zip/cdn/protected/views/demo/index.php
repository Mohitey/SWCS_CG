<h1>Investor Registration Form :: DEMO</h1>
<?php
extract($RESPONSE);
$full_name=$first_name." ".$last_name;

//echo "<pre>"; print_r($RESPONSE); echo "</pre>";
$readonly=$disabled='';
if($is_valid_sso_token===FALSE){
	$readonly=' readonly="readonly" ';
	$disabled=' disabled="disabled" ';
?> 
<form method="post" action="<?=SSO_URL?>">
	<div class="form-horizontal">
		<div class="control-group">
	 		<div class="controls">
	 			<h5>Please Authenticate via SSO to continue.</h5>			
				<input type="submit" class="btn btn-warning" value="Login via SSO" />
				<input type="hidden" name="CALL_BACK_URL" value="<?=$CALL_BACK_URL?>" />
				<input type="hidden" name="HMAC_HASH" value="<?=$HMAC_HASH?>" />
				<input type="hidden" name="SP_TAG" value="<?=$SP_TAG?>" />
			</div>
		</div>
	</div>	
</form>
<?php
}
?>
<div class="form-horizontal">
	<form method="post">
		 <div class="control-group">
			<label class="control-label">Name of Applicant</label>
			<div class="controls">
				<input <?=$readonly?> class="input-xxlarge" name="full_name" id="full_name" value="<?=@$full_name?>" type="text" placeholder="Name of Applicant" />
			</div>
		</div>
		
		<div class="control-group">
			<label class="control-label">Corresponding Address</label>
			<div class="controls">
				<input <?=$readonly?> class="input-xxlarge" value="<?=@$address?>" name="address" id="address" type="text" placeholder="Corresponding Address" />
			</div>
		</div>
					
		<div class="control-group">
			<label class="control-label">City</label>
			<div class="controls">
				<input <?=$readonly?> class="input-xxlarge" value="<?=@$city_name?>" name="city" id="city" type="text" placeholder="City" />
			</div>
		</div>
		
		<div class="control-group">
			<label class="control-label">State</label>
			<div class="controls">
				<input <?=$readonly?> class="input-xxlarge" value="<?=@$state_name?>" name="state" id="state" type="text" placeholder="State" />
			</div>
		</div>
		
		<div class="control-group">
			<label class="control-label">Pin Code</label>
			<div class="controls">
				<input <?=$readonly?> class="input-xxlarge" value="<?=@$pin_code?>"  name="pincode" id="pincode" type="text" placeholder="Pin Code" />
			</div>
		</div>
		
		<div class="control-group">
			<label class="control-label">Country</label>
			<div class="controls">
				<input <?=$readonly?> class="input-xxlarge" value="<?=@$country_name?>"  name="country" id="country" type="text" placeholder="Country" />
			</div>
		</div>
		
		<div class="control-group">
			<label class="control-label">Phone</label>
			<div class="controls">
				<input <?=$readonly?> class="input-xxlarge" name="phone" id="phone" type="text" placeholder="Phone" />
			</div>
		</div>
		
		<div class="control-group">
			<label class="control-label">Fax</label>
			<div class="controls">
				<input <?=$readonly?> class="input-xxlarge" name="fax" id="fax" type="text" placeholder="Fax" />
			</div>
		</div>
		
		<div class="control-group">
			<label class="control-label">E-mail</label>
			<div class="controls">
				<input <?=$readonly?> class="input-xxlarge" name="email" value="<?=@$email?>" id="email" type="text" placeholder="E-mail" />
			</div>
		</div>
		
		<div class="control-group">
			<label class="control-label">Mobile</label>
			<div class="controls">
				<input <?=$readonly?> class="input-xxlarge" name="mobile" value="<?=@$mobile_number?>" id="mobile" type="text" placeholder="Mobile" />
			</div>
		</div>
		
		<div class="control-group">
			<div class="controls">
				<input <?=$disabled?>  type="submit" class="btn btn-success" value="Register" />
			</div>
		</div>
	</form>
</div>