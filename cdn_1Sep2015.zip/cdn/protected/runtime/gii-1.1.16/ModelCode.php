<?php
return array (
  'template' => 'default',
  'connectionId' => 'db',
  'tablePrefix' => 'cdn_',
  'modelPath' => 'application.models',
  'baseClass' => 'CActiveRecord',
  'buildRelations' => '1',
  'commentsAsLabels' => '1',
);
