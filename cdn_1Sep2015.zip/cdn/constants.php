<?php
define("DEBUG", true);
define("ENV", 'stg');   //prod, dev, stg
define("SP_TAG","cdn");
define("APP_NAME", "CDN :: SWCS");

if (ENV == 'prod') {
    define("DB_SERVER", "localhost");
    define("DB_NAME", "swcs");
    define("DB_PASS", "iviss");
    define("DB_USER", "root");
	define("SECRET","907eb5b6e1ba70c2bb1d65bb12ae6c5e");
	define("API_BASEURL","http://clients.jumbolabs.com/SWCS/sso");
	define("CDN_BASE_URL", "http://clients.jumbolabs.com/SWCS/cdn");
	define("SSO_URL", "http://clients.jumbolabs.com/SWCS/sso/register");
	define("SSO_URL1", "http://clients.jumbolabs.com/SWCS/sso/signup/one");
	define("SSO_URL2", "http://clients.jumbolabs.com/SWCS/sso/auth/auth1");
} 
elseif(ENV == 'stg') {
    define("DB_SERVER", "localhost");
    define("DB_NAME", "jlabs_swcs");
    define("DB_PASS", "n1.8_2AU^.Zl");
    define("DB_USER", "jlabs_swcs");
	define("SECRET","907eb5b6e1ba70c2bb1d65bb12ae6c5e");
	define("API_BASEURL","http://clients.jumbolabs.com/SWCS/sso");
	define("CDN_BASE_URL", "http://clients.jumbolabs.com/SWCS/cdn");
	define("SSO_URL", "http://clients.jumbolabs.com/SWCS/sso/register");	
	define("SSO_URL1", "http://clients.jumbolabs.com/SWCS/sso/signup/one");
	define("SSO_URL2", "http://clients.jumbolabs.com/SWCS/sso/auth/auth1");
}
else {
    define("DB_SERVER", "localhost");
    define("DB_NAME", "swcs");
    define("DB_PASS", "iviss");
    define("DB_USER", "root");
	define("SECRET","907eb5b6e1ba70c2bb1d65bb12ae6c5e");
	define("API_BASEURL","http://clients.jumbolabs.com/SWCS/sso");
	define("CDN_BASE_URL", "http://clients.jumbolabs.com/SWCS/cdn");
	define("SSO_URL", "http://clients.jumbolabs.com/SWCS/sso/register");
	define("SSO_URL1", "http://clients.jumbolabs.com/SWCS/sso/signup/one");
	define("SSO_URL2", "http://clients.jumbolabs.com/SWCS/sso/auth/auth1");
}       