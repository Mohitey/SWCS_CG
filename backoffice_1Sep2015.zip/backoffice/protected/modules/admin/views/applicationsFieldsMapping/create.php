<?php
/* @var $this ApplicationsFieldsMappingController */
/* @var $model ApplicationsFieldsMapping */

$this->breadcrumbs=array(
	'Applications Fields Mappings'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List ApplicationsFieldsMapping', 'url'=>array('index')),
	array('label'=>'Manage ApplicationsFieldsMapping', 'url'=>array('admin')),
);
?>

<h1>Create ApplicationsFieldsMapping</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>