<?php
/* @var $this FileldsController */
/* @var $model Filelds */

$this->breadcrumbs=array(
	'Filelds'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List Filelds', 'url'=>array('index')),
	array('label'=>'Manage Filelds', 'url'=>array('admin')),
);
?>

<h1>Create Fields</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>