<?php
/* @var $this ApplicationsSubmittionsController */
/* @var $model ApplicationsSubmittions */
/* @var $form CActiveForm */
?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'applications-submittions-form',
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// There is a call to performAjaxValidation() commented in generated controller code.
	// See class documentation of CActiveForm for details on this.
	'enableAjaxValidation'=>false,
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($model); ?>

	<div class="row">
		<?php echo $form->labelEx($model,'application_id'); ?>
		<?php echo $form->textField($model,'application_id',array('size'=>10,'maxlength'=>10)); ?>
		<?php echo $form->error($model,'application_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'user_id'); ?>
		<?php echo $form->textField($model,'user_id',array('size'=>10,'maxlength'=>10)); ?>
		<?php echo $form->error($model,'user_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'field_id'); ?>
		<?php echo $form->textField($model,'field_id',array('size'=>10,'maxlength'=>10)); ?>
		<?php echo $form->error($model,'field_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'field_value'); ?>
		<?php echo $form->textField($model,'field_value',array('size'=>60,'maxlength'=>512)); ?>
		<?php echo $form->error($model,'field_value'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'application_status'); ?>
		<?php echo $form->textField($model,'application_status',array('size'=>1,'maxlength'=>1)); ?>
		<?php echo $form->error($model,'application_status'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->