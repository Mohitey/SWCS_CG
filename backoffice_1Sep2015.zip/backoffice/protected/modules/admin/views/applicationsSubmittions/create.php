<?php
/* @var $this ApplicationsSubmittionsController */
/* @var $model ApplicationsSubmittions */

$this->breadcrumbs=array(
	'Applications Submittions'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List ApplicationsSubmittions', 'url'=>array('index')),
	array('label'=>'Manage ApplicationsSubmittions', 'url'=>array('admin')),
);
?>

<h1>Create Application Submission</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>