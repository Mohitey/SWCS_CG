<?php
/* @var $this DepartmentsController */
/* @var $data Departments */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('dept_id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->dept_id), array('view', 'id'=>$data->dept_id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('department_name')); ?>:</b>
	<?php echo CHtml::encode($data->department_name); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('department_unique_code')); ?>:</b>
	<?php echo CHtml::encode($data->department_unique_code); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('created_on')); ?>:</b>
	<?php echo CHtml::encode($data->created_on); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('is_department_active')); ?>:</b>
	<?php echo CHtml::encode($data->is_department_active); ?>
	<br />


</div>