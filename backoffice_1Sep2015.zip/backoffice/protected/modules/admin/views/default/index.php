<?php
/* @var $this DefaultController */

$this->breadcrumbs=array(
	$this->module->id,
);
?>
<h1>Admin Panel</h1>

<ul>
    <li><a href="<?=$this->createUrl('/admin/applications/admin')?>">Manage Applications</a></li>
    <li><a href="<?=$this->createUrl('/admin/applicationsFieldsMapping/admin')?>">Manage Applications Fields Mapping</a></li>
    <li><a href="<?=$this->createUrl('/admin/applicationsSubmittions/admin')?>">Manage Applications Submission</a></li>
    <li><a href="<?=$this->createUrl('/admin/departments/admin')?>">Manage Departments</a></li>
    <li><a href="<?=$this->createUrl('/admin/filelds/admin')?>">Manage Fields</a></li>
    <li><a href="<?=$this->createUrl('/admin/landregion/admin')?>">Manage Land Region</a></li>
    <li><a href="<?=$this->createUrl('/admin/roles/admin')?>">Manage Roles</a></li>
    <li><a href="<?=$this->createUrl('/admin/userRoleMapping/admin')?>">Manage User Role Mapping</a></li>
</ul>