<?php

/**
 * This is the model class for table "bo_applications_fields_mapping".
 *
 * The followings are the available columns in table 'bo_applications_fields_mapping':
 * @property integer $app_mapping_id
 * @property string $application_id
 * @property string $field_id
 * @property string $is_mapping_active
 *
 * The followings are the available model relations:
 * @property Applications $application
 * @property Filelds $field
 */
class ApplicationsFieldsMapping extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'bo_applications_fields_mapping';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('application_id, field_id', 'required'),
			array('application_id, field_id', 'length', 'max'=>10),
			array('is_mapping_active', 'length', 'max'=>1),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('app_mapping_id, application_id, field_id, is_mapping_active', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'application' => array(self::BELONGS_TO, 'Applications', 'application_id'),
			'field' => array(self::BELONGS_TO, 'Filelds', 'field_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'app_mapping_id' => 'App Mapping',
			'application_id' => 'Application',
			'field_id' => 'Field',
			'is_mapping_active' => 'Is Mapping Active',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('app_mapping_id',$this->app_mapping_id);
		$criteria->compare('application_id',$this->application_id,true);
		$criteria->compare('field_id',$this->field_id,true);
		$criteria->compare('is_mapping_active',$this->is_mapping_active,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return ApplicationsFieldsMapping the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
