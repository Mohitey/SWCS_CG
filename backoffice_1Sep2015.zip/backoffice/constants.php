<?php
define("DEBUG", true);
define("ENV", 'stg');   //prod, dev, stg

define("APP_NAME", "Single Window Clearance System");

if (ENV == 'prod') {
    define("DB_SERVER", "localhost");
    define("DB_NAME", "swcs");
    define("DB_PASS", "iviss");
    define("DB_USER", "root");
} 
elseif(ENV == 'stg') {
    define("DB_SERVER", "localhost");
    define("DB_NAME", "jlabs_swcs");
    define("DB_PASS", "n1.8_2AU^.Zl");
    define("DB_USER", "jlabs_swcs");
}
else {
    define("DB_SERVER", "localhost");
    define("DB_NAME", "swcs");
    define("DB_PASS", "iviss");
    define("DB_USER", "root");
}       