<?php
/* @var $this FilemanagerController */

$this->breadcrumbs=array(
	'Filemanager',
);
?>
<h1>File Manager</h1>

<!-- File manager -->
<div class="widget">
	<div class="title"><img src="http://ziicms.zuyainfotech.com/themes/backend/images/icons/dark/files.png" alt="" class="titleIcon" /><h6>File Manager</h6></div>
	<div id="fm"></div>
</div>
