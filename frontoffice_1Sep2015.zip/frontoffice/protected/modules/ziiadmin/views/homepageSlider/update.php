<?php
/* @var $this HomepageSliderController */
/* @var $model HomepageSlider */

$this->breadcrumbs=array(
	'Homepage Sliders'=>array('index'),
	$model->image_id=>array('view','id'=>$model->image_id),
	'Update',
);

/*$this->menu=array(
	array('label'=>'List HomepageSlider', 'url'=>array('index')),
	array('label'=>'Create HomepageSlider', 'url'=>array('create')),
	array('label'=>'View HomepageSlider', 'url'=>array('view', 'id'=>$model->image_id)),
	array('label'=>'Manage HomepageSlider', 'url'=>array('admin')),
);*/
?>

<h1>Update HomepageSlider <?php echo $model->image_id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>