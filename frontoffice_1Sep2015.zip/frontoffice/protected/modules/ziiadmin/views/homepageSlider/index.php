<?php
/* @var $this HomepageSliderController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Homepage Sliders',
);

$this->menu=array(
	array('label'=>'Create HomepageSlider', 'url'=>array('create')),
	array('label'=>'Manage HomepageSlider', 'url'=>array('admin')),
);
?>

<h1>Homepage Sliders</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
