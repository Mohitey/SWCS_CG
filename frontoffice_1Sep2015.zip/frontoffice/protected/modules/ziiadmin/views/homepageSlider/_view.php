<?php
/* @var $this HomepageSliderController */
/* @var $data HomepageSlider */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('image_id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->image_id), array('view', 'id'=>$data->image_id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('image_caption')); ?>:</b>
	<?php echo CHtml::encode($data->image_caption); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('image_path')); ?>:</b>
	<?php echo CHtml::encode($data->image_path); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Image_order')); ?>:</b>
	<?php echo CHtml::encode($data->Image_order); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('larger_heading')); ?>:</b>
	<?php echo CHtml::encode($data->larger_heading); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('medium_red_bg_heading')); ?>:</b>
	<?php echo CHtml::encode($data->medium_red_bg_heading); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('black_bg_h1')); ?>:</b>
	<?php echo CHtml::encode($data->black_bg_h1); ?>
	<br />

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('black_bg_h2')); ?>:</b>
	<?php echo CHtml::encode($data->black_bg_h2); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('black_bg_h3')); ?>:</b>
	<?php echo CHtml::encode($data->black_bg_h3); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('added_date')); ?>:</b>
	<?php echo CHtml::encode($data->added_date); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('updated_date')); ?>:</b>
	<?php echo CHtml::encode($data->updated_date); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('is_active')); ?>:</b>
	<?php echo CHtml::encode($data->is_active); ?>
	<br />

	*/ ?>

</div>