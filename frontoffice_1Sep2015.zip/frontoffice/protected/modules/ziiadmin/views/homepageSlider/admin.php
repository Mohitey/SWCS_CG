<?php
/* @var $this HomepageSliderController */
/* @var $model HomepageSlider */

$this->breadcrumbs=array(
	'Homepage Sliders'=>array('index'),
	'Manage',
);

/*$this->menu=array(
	array('label'=>'List HomepageSlider', 'url'=>array('index')),
	array('label'=>'Create HomepageSlider', 'url'=>array('create')),
);*/

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
	$('.search-form').toggle();
	return false;
});
$('.search-form form').submit(function(){
	$('#homepage-slider-grid').yiiGridView('update', {
		data: $(this).serialize()
	});
	return false;
});
");
?>

<h1>Manage Homepage Sliders</h1>

<p>
You may optionally enter a comparison operator (<b>&lt;</b>, <b>&lt;=</b>, <b>&gt;</b>, <b>&gt;=</b>, <b>&lt;&gt;</b>
or <b>=</b>) at the beginning of each of your search values to specify how the comparison should be done.
</p>

<?php echo CHtml::link('Advanced Search','#',array('class'=>'search-button')); ?>
<div class="search-form" style="display:none">
<?php $this->renderPartial('_search',array(
	'model'=>$model,
)); ?>
</div><!-- search-form -->

<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'homepage-slider-grid',
	'dataProvider'=>$model->search(),
	'filter'=>$model,
	'columns'=>array(
		'image_id',
		'image_caption',
		'image_path',
		'Image_order',
		'larger_heading',
		'medium_red_bg_heading',
		/*
		'black_bg_h1',
		'black_bg_h2',
		'black_bg_h3',
		'added_date',
		'updated_date',
		'is_active',
		*/
		array(
			'class'=>'CButtonColumn',
		),
	),
)); ?>
