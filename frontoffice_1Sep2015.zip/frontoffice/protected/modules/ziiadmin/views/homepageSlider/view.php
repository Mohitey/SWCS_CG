<?php
/* @var $this HomepageSliderController */
/* @var $model HomepageSlider */

$this->breadcrumbs=array(
	'Homepage Sliders'=>array('index'),
	$model->image_id,
);

/*$this->menu=array(
	array('label'=>'List HomepageSlider', 'url'=>array('index')),
	array('label'=>'Create HomepageSlider', 'url'=>array('create')),
	array('label'=>'Update HomepageSlider', 'url'=>array('update', 'id'=>$model->image_id)),
	array('label'=>'Delete HomepageSlider', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->image_id),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage HomepageSlider', 'url'=>array('admin')),
);*/
?>

<h1>View HomepageSlider #<?php echo $model->image_id; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'image_id',
		'image_caption',
		'image_path',
		'Image_order',
		'larger_heading',
		'medium_red_bg_heading',
		'black_bg_h1',
		'black_bg_h2',
		'black_bg_h3',
		'added_date',
		'updated_date',
		'is_active',
	),
)); ?>
