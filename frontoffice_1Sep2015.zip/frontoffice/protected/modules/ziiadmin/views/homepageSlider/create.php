<?php
/* @var $this HomepageSliderController */
/* @var $model HomepageSlider */

$this->breadcrumbs=array(
	'Homepage Sliders'=>array('index'),
	'Create',
);

/*$this->menu=array(
	array('label'=>'List HomepageSlider', 'url'=>array('index')),
	array('label'=>'Manage HomepageSlider', 'url'=>array('admin')),
);*/
?>

<h1>Create HomepageSlider</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>