<table border="0" cellspacing="0" cellpadding="0" width="635" align="center" style="border: 4px solid #9d1a05;
        background-color: #fff;">
        
        <tr>
            <td style="padding: 10px;" colspan="2">
                <table width="615" border="0" align="center" cellpadding="0" cellspacing="0">
                    <tr height="20">
                        <td></td>
                    </tr>
                    <tr>
                        <td height="28" align="left" valign="top" style="color: #000; font-family: Verdana;
                            font-size: 13px;">
                            Hi <?=$userName?>,<br />
                            Welcome To <?=$cmo_portal?><br />
                            <br />
                           
                            <p>
                                <h3>Final step...</h3>
                                Please verify your account by confirming this email account. It's easy — just click on the link below.
                                <br /><br />
                                <a href="<?=$activation_link?>" style="color:#9d1a05; font-weight:bold; text-decoration:none;">Click Here To Verify Your Email</a>
                                <br />
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="middle" style="color: #000; font-size: 13px; font-family: Verdana;
                            font-weight: bold;">
                            <br />
                            Thanks for Registering !!!
                            <br />
                            Chief Minister's Office Team<br />
                            Special Senior Secretary to Chief Minister,<br />
                            4th Floor, Civil Secretariat,Sector 1,<br />
                            Chandigarh<br />
                            <a style="color: #333333;
                                    font-family: Verdana; text-decoration: underline; font-size: 12px;" href="mailto:cmharyana@nic.in">
                                Email: cmharyana@nic.in
                            </a>
                            <br />
                        </td>
                    </tr>
                    <tr height="20">
                        <td></td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr height="20">
            <td colspan="2"></td>
        </tr>
        
        <tr height="20">
            <td colspan="2"></td>
        </tr>
        <tr style="background-color: #9d1a05; color:#FFF;">
            <td align="center" valign="middle" colspan="2">
                <div style="line-height: 18px; color: #fff; font-family: Verdana; font-size: 12px;">
                   
                    <p style="text-align: center;">
                        CM Portal | <a href="http://www.weexcelindia.com/" style="color:#fff; text-decoration:none;">
                            Designed & Developed By WeExcel Softwares
                        </a>
                    </p>
                </div>
            </td>
        </tr>
    </table>