<?php

/**
 * This is the model class for table "bo_manage_homepage_slider".
 *
 * The followings are the available columns in table 'bo_manage_homepage_slider':
 * @property integer $image_id
 * @property string $image_caption
 * @property string $image_path
 * @property integer $order_number
 * @property string $added_date
 * @property string $updated_date
 * @property string $is_active
 */
class ManageHomepageSlider extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'bo_manage_homepage_slider';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('image_caption, image_path, added_date', 'required'),
			array('order_number', 'numerical', 'integerOnly'=>true),
			array('image_caption', 'length', 'max'=>255),
			array('image_path', 'length', 'max'=>99),
			array('is_active', 'length', 'max'=>1),
			array('updated_date', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('image_id, image_caption, image_path, order_number, added_date, updated_date, is_active', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'image_id' => 'Image',
			'image_caption' => 'Image Caption',
			'image_path' => 'Image Path',
			'order_number' => 'Order Number',
			'added_date' => 'Added Date',
			'updated_date' => 'Updated Date',
			'is_active' => 'Is Active',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;
		$criteria->compare('image_id',$this->image_id);
		$criteria->compare('image_caption',$this->image_caption,true);
		$criteria->compare('image_path',$this->image_path,true);
		$criteria->compare('order_number',$this->order_number);
		$criteria->compare('added_date',$this->added_date,true);
		$criteria->compare('updated_date',$this->updated_date,true);
		$criteria->compare('is_active',$this->is_active,true);
		die("mar gya");
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return ManageHomepageSlider the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
