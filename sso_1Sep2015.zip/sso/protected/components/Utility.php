<?php

class Utility{

	public function logEntry(){
		
	}	
} 