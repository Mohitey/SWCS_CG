<h1>SSO :: Auth Levels</h1>
<ul>
    <li><b>Auth Level 1:</b> Username and Password (one factor authentication)</li>
    <li><b>Auth Level 2:</b> Mobile Number and Email (Two factor authentication)</li>
    <li><b>Auth Level 3:</b> Mobile and OTP (Two factor authentication)</li>
</ul>
