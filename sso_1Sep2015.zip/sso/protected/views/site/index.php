<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name;
?>

<h1>Welcome to <i><?php echo CHtml::encode(Yii::app()->name); ?></i></h1>


<p><a href="<?=$this->createUrl('/api')?>"> API Documentation </a></p>

<h4> About SSO </h4>
<p>
	 Lorem ipsum dolor sit amet, pede amet nonummy, lorem enim integer malesuada varius. Aliquet mauris vehicula, magna rutrum ante lorem magna, ac ut justo. Libero amet adipiscing nisl, lorem ut metus blandit non. Purus convallis non neque convallis fusce ullamcorper, eu wisi, hendrerit ligula arcu pulvinar nisl ut. Non sollicitudin eros, sed necessitatibus eleifend pharetra commodo, pellentesque metus. Magnis elit vel donec placerat neque eu. Dui recusandae leo, ultrices dolor, quibusdam vestibulum voluptas, augue quam et arcu ante in rutrum, dictum sollicitudin ultrices. Orci dictum eros mauris tortor tempus.

Ut quis arcu sit proin mauris, et sem ut vitae ac vitae, nulla eleifend, vestibulum pede lacus vestibulum a aliquam nulla. Quisque etiam, aliquam amet at sagittis sit lacus, suscipit blandit cum senectus lectus dignissim, interdum quam dui duis etiam enim velit. Aliquam nunc rutrum. Eu eros sodales purus, quis rutrum nullam. Mi viverra. Class lorem eget torquent et vestibulum tellus.
</p>

