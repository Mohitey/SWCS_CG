<?php
define("DEBUG", true);
define("ENV", 'stg');   //prod, dev, stg
define("APP_NAME", "SSWS");
if (ENV == 'prod') {
    define("DB_SERVER", "localhost");
    define("DB_NAME", "swcs");
    define("DB_PASS", "iviss");
    define("DB_USER", "root");	
	define("API_BASEURL","http://clients.jumbolabs.com/SWCS/sso");
} 
elseif(ENV == 'stg') {
    define("DB_SERVER", "localhost");
    define("DB_NAME", "jlabs_swcs");
    define("DB_PASS", "n1.8_2AU^.Zl");
    define("DB_USER", "jlabs_swcs");	
	define("API_BASEURL","http://clients.jumbolabs.com/SWCS/sso");
}
else {
    define("DB_SERVER", "localhost");
    define("DB_NAME", "swcs");
    define("DB_PASS", "iviss");
    define("DB_USER", "root");	
	define("API_BASEURL","http://clients.jumbolabs.com/SWCS/sso");
}     
define("PASSWORD_SECRET_KEY", 'b99#3H?AQ7Zfsj');  
define("PRIVATE_KEY","6LfcnQsTAAAAAIgbSyqg0qkjO2yOvhj6SqX_y3Js");
define("PUBLIC_KEY","6LfcnQsTAAAAAAP0hADhJ8Ow19ExY-Yl85TLdXVX"); 